/* Copyright 2021 David Wieland <info@datulab.tech>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include "quantum.h"

// This a shortcut to help you visually see your layout.
// The following is an example using the Planck MIT layout
// The first section contains all of the arguments
// The second converts the arguments into a two-dimensional array
#define LAYOUT_all(\
	K000,       K001, K011, K002, K012,    K003, K013, K004, K014,    K015, K006, K016, K007,    K017, K008, K018,  \
	K020, K030, K021, K031, K022, K032, K023, K033, K024, K034, K025, K035, K026, K036, K027,    K037, K028, K038,  \
	K040, K050, K041, K051, K042, K052, K043, K053, K044, K054, K045, K055, K046, K056,          K057, K048, K058,  \
	K060, K070, K061, K071, K062, K072, K063, K073, K064, K074, K065, K075, K066, K076,                             \
 	K080, K090, K081, K091, K082, K092, K083, K093, K084, K094, K085, K095, K086, K096,                K088,        \
	K100, K110, K101,                   K113,                   K105, K115, K106, K116,          K117, K108, K118   \
) { \
	{ K000,  KC_NO, K001,  K011,  K002,  K012,  K003,  K013,  K004,  K014,  K015  }, \
	{ K020,  K030,  K021,  K031,  K022,  K032,  K023,  K033,  K024,  K034,  K025  }, \
	{ K040,  K050,  K041,  K051,  K042,  K052,  K043,  K053,  K044,  K054,  K045  }, \
	{ K060,  K070,  K061,  K071,  K062,  K072,  K063,  K073,  K064,  K074,  K065  }, \
	{ K080,  K081,  K091,  K082,  K092,  K083,  K093,  K084,  K094,  K085,  K095  }, \
	{ K100,  K110,  K101,  K113,  K105,  K115,  K106,  K116,  K117,  K108,  K118  }, \
	{ K006,  K016,  K007,  K017,  K008,  K018,  K075,  K076,  KC_NO, KC_NO, KC_NO }, \
	{ K035,  K026,  K027,  K037,  K028,  K038,  K086,  K088,  KC_NO, KC_NO, KC_NO }, \
	{ K055,  K046,  K056,  K057,  K048,  K058,  KC_NO, KC_NO, KC_NO, KC_NO, KC_NO } \
}


#define LAYOUT_tkl_ansi(\
	K000,       K001, K011, K002, K012,    K003, K013, K004, K014,    K015, K006, K016, K007,    K017, K008, K018,  \
	K020, K030, K021, K031, K022, K032, K023, K033, K024, K034, K025, K035, K026, K027,          K037, K028, K038,  \
	K040, K050, K041, K051, K042, K052, K043, K053, K044, K054, K045, K055, K046, K056,          K057, K048, K058,  \
	K060, K070, K061, K071, K062, K072, K063, K073, K064, K074, K065, K075,  K076,                                  \
 	K080,     K081, K091, K082, K092, K083, K093, K084, K094, K085, K095,      K086,                   K088,        \
	K100, K110, K101,                   K113,                   K105, K115, K106, K116,          K117, K108, K118   \
) { \
	{ K000,  KC_NO, K001,  K011,  K002,  K012,  K003,  K013,  K004,  K014,  K015  }, \
	{ K020,  K030,  K021,  K031,  K022,  K032,  K023,  K033,  K024,  K034,  K025  }, \
	{ K040,  K050,  K041,  K051,  K042,  K052,  K043,  K053,  K044,  K054,  K045  }, \
	{ K060,  K070,  K061,  K071,  K062,  K072,  K063,  K073,  K064,  K074,  K065  }, \
	{ K080,  K081,  K091,  K082,  K092,  K083,  K093,  K084,  K094,  K085,  K095  }, \
	{ K100,  K110,  K101,  K113,  K105,  K115,  K106,  K116,  K117,  K108,  K118  }, \
	{ K006,  K016,  K007,  K017,  K008,  K018,  K075,  K076,  KC_NO, KC_NO, KC_NO }, \
	{ K035,  K026,  K027,  K037,  K028,  K038,  K086,  K088,  KC_NO, KC_NO, KC_NO }, \
	{ K055,  K046,  K056,  K057,  K048,  K058,  KC_NO, KC_NO, KC_NO, KC_NO, KC_NO } \
}

#define LAYOUT_tkl_ansi_wkl(\
	K000,       K001, K011, K002, K012,    K003, K013, K004, K014,    K015, K006, K016, K007,    K017, K008, K018,  \
	K020, K030, K021, K031, K022, K032, K023, K033, K024, K034, K025, K035, K026, K027,          K037, K028, K038,  \
	K040, K050, K041, K051, K042, K052, K043, K053, K044, K054, K045, K055, K046, K056,          K057, K048, K058,  \
	K060, K070, K061, K071, K062, K072, K063, K073, K064, K074, K065, K075,  K076,                                  \
 	K080,     K081, K091, K082, K092, K083, K093, K084, K094, K085, K095,      K086,                   K088,        \
	K100,       K101,                   K113,                         K115,       K116,          K117, K108, K118   \
) { \
	{ K000,  KC_NO, K001,  K011,  K002,  K012,  K003,  K013,  K004,  K014,  K015  }, \
	{ K020,  K030,  K021,  K031,  K022,  K032,  K023,  K033,  K024,  K034,  K025  }, \
	{ K040,  K050,  K041,  K051,  K042,  K052,  K043,  K053,  K044,  K054,  K045  }, \
	{ K060,  K070,  K061,  K071,  K062,  K072,  K063,  K073,  K064,  K074,  K065  }, \
	{ K080,  K081,  K091,  K082,  K092,  K083,  K093,  K084,  K094,  K085,  K095  }, \
	{ K100,  K110,  K101,  K113,  K105,  K115,  K106,  K116,  K117,  K108,  K118  }, \
	{ K006,  K016,  K007,  K017,  K008,  K018,  K075,  K076,  KC_NO, KC_NO, KC_NO }, \
	{ K035,  K026,  K027,  K037,  K028,  K038,  K086,  K088,  KC_NO, KC_NO, KC_NO }, \
	{ K055,  K046,  K056,  K057,  K048,  K058,  KC_NO, KC_NO, KC_NO, KC_NO, KC_NO } \
}




